export class Users {
    employeeMail: string='';
    employeeId: string = '';
    employeeAge: number = 0;
    employeeName: string = '';
}
