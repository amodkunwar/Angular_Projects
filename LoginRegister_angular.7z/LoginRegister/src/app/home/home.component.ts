import { EmployeeService } from './../employee.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

loginStatus = false;

  constructor(private employeeService: EmployeeService, private router: Router) { }

  ngOnInit(): void {    
    this.employeeService.loginStatus.subscribe(data=> {
      this.loginStatus = data;
    })
    
    if(!this.loginStatus){
      this.router.navigateByUrl("login");
    }

  }

}
