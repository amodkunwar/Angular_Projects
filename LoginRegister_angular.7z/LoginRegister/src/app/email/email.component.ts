import { EmployeeService } from './../employee.service';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-email',
  templateUrl: './email.component.html',
  styleUrls: ['./email.component.css']
})
export class EmailComponent implements OnInit {

  emailForm: FormGroup;
  emailMessage = '';
  emailStatus = false;
  resetForm: FormGroup;
  resetStatus = false;
  resetMessage = '';
  emailValue = '';
  passwordChangeStatus = false;

  constructor(private formBuilder: FormBuilder, private employeeService: EmployeeService) {
    this.emailForm = formBuilder.group({
      email: ['', [Validators.email, Validators.required]]
    });

    this.resetForm = formBuilder.group({
      code: ['', [Validators.required]],
      password: ['', Validators.required]
    });
   }

  ngOnInit(): void {
  }

  emailSend() {
    const emailValue = this.emailForm.value.email;
     const form = { employeeMail: emailValue }
     this.employeeService.sendEmail(emailValue, form).subscribe(response => {
      this.emailStatus = true;
      this.emailMessage = 'Email sent successfully !';
      this.employeeService.updateMail(emailValue);
      this.reset();
      this.passwordChangeStatus = true;
    })
  }

  reset() {
    this.emailForm.reset();
  }

  resetPassword() {
    const codeValue = this.resetForm.value.code;
    const newPassword = this.resetForm.value.password;
    const form = {code: codeValue, password: newPassword};
    this.employeeService.getMail().subscribe(res=> {
      this.emailValue = res;
    })
    this.employeeService.resetPassword(this.emailValue, form).subscribe(response => {
      this.resetStatus = true;
      this.resetMessage = 'Password updated successfully !!';
      this.resetForm.reset();
      this.emailStatus = false;
      this.passwordChangeStatus = true;
    })
  }

}
