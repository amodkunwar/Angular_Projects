export class Global {
    public static loggedInStatus: boolean = false;
    public static employeeId: string = '';
}