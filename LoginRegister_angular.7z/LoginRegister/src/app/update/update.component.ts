import { Global } from './../global';
import { map } from 'rxjs/operators';
import { Users } from './../users';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { EmployeeService } from './../employee.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {

  update: FormGroup;
  find: FormGroup;
  loginStatus = false;
  updateStatus = false;
  deleteStatus = false;
  deleteMessage = '';
  updateMessage = '';
  isVisible = false;
  isError = false;
  searchError = '';
  empId = '';
  invalidId = false;
  invalidSearch = '';
  dataUpdated = false;
  age: number = 0;
  name: string = '';

  users: Users = new Users;

  employeeId = '';

  // employeeId = Global.employeeId;

  constructor(private employeeService: EmployeeService, private router: Router, private formBuilder: FormBuilder) {

    this.update = this.formBuilder.group({
      email: ['', Validators.required],
      name: ['', Validators.required],
      age: ['', Validators.required],
      id: ['', Validators.required]
    });

    this.find = this.formBuilder.group({
      search: ['', Validators.  required]
    })

  }

  ngOnInit(): void {
    this.employeeService.loginStatus.subscribe(response => {
      this.loginStatus = response;
    })

    if (!this.loginStatus) {
      this.router.navigateByUrl('login');
    }
    
  }

  putData() {
    const mail = this.update.value.email;
    const nm = this.update.value.name;
    const empAge = this.update.value.age;
    const empId = this.update.value.id;
    const form = { employeeMail: mail, employeeName: nm, employeeAge: empAge, employeeId: empId };
    this.employeeService.editEmployee(form, empId).subscribe(response => {
      this.updateStatus = true;
      this.updateMessage = 'updated successfully !';
      this.isVisible = true;
      setTimeout(() => this.isVisible = false, 2000);
      this.users = response;
      this.empId = this.users.employeeId;
      this.dataUpdated = true;
      this.age = this.users.employeeAge;
      this.name = this.users.employeeName;
    });
  }

  search() {
    const empIdd = this.find.value.search;
    console.log("Emp id : "+empIdd);
    this.employeeService.getEmpIdValue().subscribe(response => {
      this.employeeId = response;
    })
    console.log("Global employee "+this.employeeId);
    
    console.log(this.employeeId.localeCompare(empIdd));
    
    if (this.employeeId.localeCompare(empIdd)===0) {
      this.employeeService.getById(empIdd).subscribe(response => {
        this.users = response;
      },
        error => {
          this.isError = true;
          this.searchError = 'Id not found!';
        })
    }else{
      this.invalidId = true;
      this.invalidSearch = 'Please enter your employee id';
    }
  }

  delete() {
    const empId = this.update.value.id;
    this.employeeService.deleteEmployee(empId).subscribe(resposne => {
      this.deleteStatus = true;
      this.deleteMessage = 'Deleted successfully !';
      this.resetForm();
      this.isVisible = true;
      // this.setTimeOutStatus(this.isVisible);
      setTimeout(() => this.isVisible = false, 2000);
    })
  }

  resetForm() {
    this.update.reset();
  }

  // setTimeOutStatus(status: boolean){
  //   setTimeout(() => status = false, 1000);
  // }
}
