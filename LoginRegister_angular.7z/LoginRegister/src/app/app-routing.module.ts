import { DeleteComponent } from './delete/delete.component';
import { SearchComponent } from './search/search.component';
import { EmailComponent } from './email/email.component';
import { PasswordComponent } from './password/password.component';
import { AgeComponent } from './age/age.component';
import { NameComponent } from './name/name.component';
import { UpdateComponent } from './update/update.component';
import { EventsComponent } from './events/events.component';
import { MainComponent } from './main/main.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';

const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'main', component: MainComponent },
  { path: 'delete', component: DeleteComponent },
  { path: 'login', component: LoginComponent },
  { path: 'events', component: EventsComponent },
  { path: 'update', component: UpdateComponent },
  { path: 'name', component: NameComponent },
  { path: 'age', component: AgeComponent },
  { path: 'password', component: PasswordComponent },
  { path: 'email', component: EmailComponent },
  { path: 'search', component: SearchComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { relativeLinkResolution: 'legacy' })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
