import { LoginComponent } from './../login/login.component';
import { Global } from './../global';
import { EmployeeService } from './../employee.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
// import { Howl } from 'howler';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {

  loginStatus = false;

  constructor(public employeeService: EmployeeService, private router: Router) { }

  ngOnInit(): void {
    // var sound = new Howl({ src: ['assets/songs/song.mp3'], html5 :true, autoplay: true, loop: true, volume: 0.5 }); 
    // sound.play()
    this.employeeService.loginStatus.subscribe(response => {
      this.loginStatus = response;
    })

    if(!this.loginStatus){
      this.router.navigateByUrl('login');
    }
  }

  logout() {
    this.employeeService.updateLoginStatus(false);
    localStorage.removeItem('token');
    localStorage.clear();
    this.router.navigateByUrl('login');
  }

}
