import { EmployeeService } from './employee.service';
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable, Injector } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TokenInterceptorService implements HttpInterceptor {

  constructor(private injector: Injector) { }

  ngOnInit() {}

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    let employeeService = this.injector.get(EmployeeService);
    req = req.clone({
      setHeaders: {
        Authorization: `Bearer ${employeeService.getToken()}`
      }
    });
    console.log(req);

    return next.handle(req);
  }

}
