import { Admin } from './admin';
import { Users } from './users';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  private status = new BehaviorSubject(false);
  public loginStatus = this.status.asObservable();

  private empId = new BehaviorSubject("");
  public empIdValue = this.empId.asObservable();

  private empMail = new BehaviorSubject("");
  private empMailValue = this.empMail.asObservable();

  constructor(private httpClient: HttpClient) { }

  updateMail(value: string){
    this.empMail.next(value);
  }

  getMail() {
    return this.empMailValue;
  }

  updateEmpValue(value: string) {
    this.empId.next(value);
  }

  getEmpIdValue() {
    return this.empIdValue;
  }

  updateLoginStatus(value: any) {
    this.status.next(value);
  }

  getLoginStatus() {
    return this.loginStatus;
  }

  postEmployee(employeeRequest: any) {
    return this.httpClient.post("http://localhost:9090/employee/register", employeeRequest);
  }

  postLoginEmployee(employeeLoginRequest: any) {
    return this.httpClient.post<Users>("http://localhost:9090/employee/login", employeeLoginRequest);
  }

  isLoggedIn() {
    return true;
  }

  getToken() {
    localStorage.setItem('token', 'sdfsdfsdfsdfsdfsdfjsdfjsd1212121212121');
    return localStorage.getItem('token');
  }

  editEmployee(request: any, empId: string) {
    return this.httpClient.put<Users>("http://localhost:9090/employee/edit/" + empId, request)
  }

  getById(empId: string) {
    return this.httpClient.get<Users>("http://localhost:9090/employee/" + empId);
  }

  forgotPassword(empEmail: string, form: any) {
    return this.httpClient.put("http://localhost:9090/employee/" + empEmail, form);
  }

  sendEmail(email: string, form: any) {
    return this.httpClient.post("http://localhost:9090/employee/" + email, form, {responseType: 'text'});
  }

  deleteEmployee(empId: string) {
    return this.httpClient.delete("http://localhost:9090/employee/delete/" +empId);
  }

  resetPassword(empEmail: string, form: any){
    return this.httpClient.put("http://localhost:9090/employee/" + empEmail, form, {responseType: 'text'});
  }

  postLoginAdmin(adminRequest: any) {
    return this.httpClient.post<Admin>("http://localhost:9090/employee/admin", adminRequest);
  }

}
