import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { EmployeeService } from './../employee.service';
import { Component, OnInit } from '@angular/core';
import { Users } from '../users';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  find: FormGroup;
  loginStatus = false;
  updateStatus = false;
  empMail = '';
  empId = '';
  empAge = 0;
  empName = '';
  isError = false;
  searchError = '';
  searchStatus = false;

  users: Users = new Users;

  constructor(private employeeService: EmployeeService, private router: Router, private formBuilder: FormBuilder) { 
    this.find = this.formBuilder.group({
      search: ['', Validators.required]
    })

  }

  ngOnInit(): void {
    
  }

  search() {
    const empIdd = this.find.value.search;
    this.employeeService.getById(empIdd).subscribe(response => {
      this.users = response;
      this.searchStatus = true;
    },
    error => {
      this.isError = true;
      this.searchError = 'Id not found!';
    })
  }

}
