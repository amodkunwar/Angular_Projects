import { TokenInterceptorService } from './token-interceptor.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { RegisterComponent } from './register/register.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { LoginComponent } from './login/login.component';
import { MainComponent } from './main/main.component';
import { HeaderComponent } from './header/header.component';
import { EventsComponent } from './events/events.component';
import { UpdateComponent } from './update/update.component';
import { NameComponent } from './name/name.component';
import { EmailComponent } from './email/email.component';
import { AgeComponent } from './age/age.component';
import { PasswordComponent } from './password/password.component';
import { SearchComponent } from './search/search.component';
import { CommonModule } from '@angular/common';
import { DeleteComponent } from './delete/delete.component';
import { AdminMainComponent } from './admin-main/admin-main.component'; 

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    RegisterComponent,
    LoginComponent,
    MainComponent,
    HeaderComponent,
    EventsComponent,
    UpdateComponent,
    NameComponent,
    EmailComponent,
    AgeComponent,
    PasswordComponent,
    SearchComponent,
    DeleteComponent,
    AdminMainComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    CommonModule
  ],
  providers: [{
    provide: HTTP_INTERCEPTORS,
    useClass: TokenInterceptorService,
    multi: true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
