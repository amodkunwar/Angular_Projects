import { Admin } from './../admin';
import { ErrorMessage } from './../model/ErrorMessage';
import { TokenInterceptorService } from './../token-interceptor.service';
import { Global } from './../global';
import { EmployeeService } from './../employee.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpHeaders } from '@angular/common/http';
import { Users } from '../users';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  login: FormGroup;
  // isLoggedIn = false;

  global = Global.loggedInStatus;
  // employeeId = Global.employeeId;

  employeeId: string = '';

  token: any;
  errorMessage: string = '';

  users: Users = new Users;
  inValidCredentials = false;
  admin: Admin = new Admin;

  constructor(private formBuilder: FormBuilder, public employeeService: EmployeeService, private router: Router) {
    this.login = this.formBuilder.group({
      email: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    // if (!this.global) {
    //   this.router.navigate(['../login'])
    // }
  }

  loginApp() {
    const emailId = this.login.value.email;
    const pwd = this.login.value.password;
    const loginRequest = { employeeMail: emailId, employeePassword: pwd };
    
    this.employeeService.postLoginEmployee(loginRequest).subscribe(data => {
      this.global = true;
      this.employeeService.updateLoginStatus(this.global);
      this.router.navigateByUrl('/main');
      // localStorage.setItem('token', 'sdfsdfsdfsdfsdfsdfjsdfjsd1212121212121');
      localStorage.getItem('token');
      this.employeeService.isLoggedIn; 
      this.users = data;
      this.employeeService.updateEmpValue(this.users.employeeId);
      this.employeeService.getEmpIdValue().subscribe(response => {
        this.employeeId = response;
      })
      console.log("Global email value is "+this.employeeId);
    },
    error => {
      this.inValidCredentials = true;
      this.errorMessage = 'Invalid Credentials';
    })
  }

  adminLoginApp() {
    const emailId = this.login.value.email;
    const pwd = this.login.value.password;
    const loginRequest = { adminMail: emailId, adminPwd: pwd };
    this.employeeService.postLoginAdmin(loginRequest).subscribe(data => {
      this.global = true;
      this.employeeService.updateLoginStatus(this.global);
      this.router.navigateByUrl('/main');
      // localStorage.setItem('token', 'sdfsdfsdfsdfsdfsdfjsdfjsd1212121212121');
      localStorage.getItem('token');
      this.employeeService.isLoggedIn; 
      this.admin = data;
      this.employeeService.updateEmpValue(this.users.employeeId);
      this.employeeService.getEmpIdValue().subscribe(response => {
        this.employeeId = response;
    })
  },
  error => {
    this.inValidCredentials = true;
    this.errorMessage = 'Invalid Credentials';
  });

}


}
