import { EmployeeService } from './../employee.service';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  form: FormGroup;
  mgs = false;

  constructor(private formBuilder: FormBuilder, private employeeService: EmployeeService) {

    this.form = this.formBuilder.group({
      email: ['', [Validators.required, Validators.
        email]],
      password: ['', Validators.required],
      id: ['', Validators.required],
      age: ['', [Validators.required, Validators.minLength(6)]],
      name: ['', Validators.required]
    });

  }

  ngOnInit(): void {
    document.body.classList.add('bg-img');
  }

  postData() {
    const id = this.form.value.id;
    const name = this.form.value.name;
    const age = this.form.value.age;
    const mail = this.form.value.email;
    const pwd = this.form.value.password;
    const formData = { employeeId: id, employeeName: name, employeeAge: age, employeeMail: mail, employeePassword: pwd };
    this.employeeService.postEmployee(formData).subscribe(data => {
      this.mgs = true;
    });
    this.resetForm();
  }

  resetForm() {
    this.form.reset();
  }

}
