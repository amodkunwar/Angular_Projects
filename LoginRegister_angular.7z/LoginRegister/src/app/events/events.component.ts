import { EmployeeService } from './../employee.service';
import { Global } from './../global';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-events',
  templateUrl: './events.component.html',
  styleUrls: ['./events.component.css']
})
export class EventsComponent implements OnInit {

  global = Global.loggedInStatus;
  constructor(private router: Router, private employeeService: EmployeeService) { }

  ngOnInit(): void {
    this.employeeService.loginStatus.subscribe(response => {
      this.global = response;
    })
    if (!this.global) {
      this.router.navigate(['../login'])
    }
  }

}
