export class Admin {
    adminMail: string='';
    adminId: string = '';
    adminAge: number = 0;
    adminName: string = '';
}
