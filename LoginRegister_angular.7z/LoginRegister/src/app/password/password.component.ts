import { EmployeeService } from './../employee.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-password',
  templateUrl: './password.component.html',
  styleUrls: ['./password.component.css']
})
export class PasswordComponent implements OnInit {

  password: FormGroup;
  isPasswordUpdated = false;

  constructor(private formBuilder: FormBuilder, private employeeService: EmployeeService) {
    this.password = formBuilder.group({
      email: ['', [Validators.email, Validators.required]],
      pwd: ['', Validators.required]
    })
  }

  ngOnInit(): void {
  }

  forgotPassword() {
    const empEmail = this.password.value.email;
    const empPwd = this.password.value.pwd;
    const form = {employeePassword: empPwd};
    this.employeeService.forgotPassword(empEmail, form).subscribe(response => {
      this.isPasswordUpdated = true;
      this.formReset();
    })
  }

  formReset() {
    this.password.reset();
  }

  // get f() { return this.password.controls; }

}
