export class ErrorMessage {
    errorMessage: string = '';
}