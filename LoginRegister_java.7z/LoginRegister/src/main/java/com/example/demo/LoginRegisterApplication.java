package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.example.demo.entity.Admin;
import com.example.demo.entity.Employee;
import com.example.demo.repository.AdminRepository;
import com.example.demo.repository.EmployeeRepository;

@SpringBootApplication
@EnableJpaRepositories
public class LoginRegisterApplication implements CommandLineRunner {

	@Autowired
	private EmployeeRepository employeeRepository;

	@Autowired
	private AdminRepository adminRepository;

	public static void main(String[] args) {
		SpringApplication.run(LoginRegisterApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		Employee employee = new Employee();
		employee.setEmployeeAge(25);
		employee.setEmployeeId("1");
		employee.setEmployeeMail("amodkunwar@gmail.com");
		employee.setEmployeeName("Amod Kunwar");
		employee.setEmployeePassword("a");
		employeeRepository.save(employee);
		Employee employee1 = new Employee();
		employee1.setEmployeeAge(25);
		employee1.setEmployeeId("2");
		employee1.setEmployeeMail("pramodkunwar@gmail.com");
		employee1.setEmployeeName("Pramod Kunwar");
		employee1.setEmployeePassword("b");
		employeeRepository.save(employee1);

		Admin admin = new Admin();
		admin.setAdminAge(27);
		admin.setAdminId("1");
		admin.setAdminMail("amodkunwar5@gmail.com");
		admin.setAdminName("ABC");
		admin.setAdminPwd("12345");
		adminRepository.saveAndFlush(admin);

	}

	@Bean
	public WebMvcConfigurer corsConfigurer() {
		return new WebMvcConfigurer() {
			@Override
			public void addCorsMappings(CorsRegistry registry) {
				registry.addMapping("/employee").allowedOrigins("http://localhost:4200");
			}
		};
	}
	
}
