package com.example.demo.exception;

public class ApplicationException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String code;
	private String detailDesc;

	public ApplicationException() {
	}

	public ApplicationException(String code, String message) {
		super(message);
		this.code = code;
	}

	public ApplicationException(Exception exception) {
		super(exception);
	}

	public ApplicationException(String message, Throwable throwable) {
		super(message, throwable);
	}

	public ApplicationException(String code, String message, String detailDesc) {
		super(message);
		this.code = code;
		this.detailDesc = detailDesc;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDetailDesc() {
		return detailDesc;
	}

	public void setDetailDesc(String detailDesc) {
		this.detailDesc = detailDesc;
	}

}
