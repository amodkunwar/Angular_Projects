package com.example.demo.exception;

public class AdminNotFoundException extends RuntimeException {
	

}
