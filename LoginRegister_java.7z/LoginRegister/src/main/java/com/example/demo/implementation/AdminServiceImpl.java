package com.example.demo.implementation;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Admin;
import com.example.demo.exception.ApplicationException;
import com.example.demo.repository.AdminRepository;
import com.example.demo.request.AdminRequest;
import com.example.demo.response.AdminResponse;
import com.example.demo.service.AdminService;

@Service
@Transactional
public class AdminServiceImpl implements AdminService {

	@Autowired
	private AdminRepository adminRepository;

	@Override
	public AdminResponse adminLogin(AdminRequest adminRequest) {
		AdminResponse setAdminResponse = null;
		Optional<Admin> optionalAdmin = Optional.ofNullable(adminRepository.findByEmail(adminRequest.getAdminMail()))
				.orElseThrow(() -> new ApplicationException("400", "Invalid credentials"));
		if (optionalAdmin.isPresent() && optionalAdmin.get().getAdminPwd().equals(adminRequest.getAdminPwd())) {
			setAdminResponse = setAdminResponse(optionalAdmin.get());
		} else {
			throw new ApplicationException("400", "Invalid credentials");
		}
		return setAdminResponse;
	}

	private AdminResponse setAdminResponse(Admin admin) {
		AdminResponse adminResponse = new AdminResponse();
		adminResponse.setAdminAge(admin.getAdminAge());
		adminResponse.setAdminId(admin.getAdminId());
		adminResponse.setAdminMail(admin.getAdminMail());
		adminResponse.setAdminName(admin.getAdminName());
		adminResponse.setAdminPwd(admin.getAdminPwd());
		return null;
	}

}
