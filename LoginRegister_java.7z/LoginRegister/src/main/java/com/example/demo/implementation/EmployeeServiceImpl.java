package com.example.demo.implementation;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Employee;
import com.example.demo.repository.EmployeeRepository;
import com.example.demo.request.EmployeeRequest;
import com.example.demo.response.EmployeeResponse;
import com.example.demo.service.EmployeeService;

@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {
	
	Logger logger = LoggerFactory.getLogger(EmployeeServiceImpl.class);

	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public List<EmployeeResponse> getAllEmployee() {
		List<Employee> allEmployees = employeeRepository.findAll();
		List<EmployeeResponse> list = new ArrayList<>();
		allEmployees.forEach(emp -> {
			EmployeeResponse employeeResponse = new EmployeeResponse();
			employeeResponse.setEmployeeAge(emp.getEmployeeAge());
			employeeResponse.setEmployeeId(emp.getEmployeeId());
			employeeResponse.setEmployeeMail(emp.getEmployeeMail());
			employeeResponse.setEmployeeName(emp.getEmployeeName());
			employeeResponse.setEmployeePassword(emp.getEmployeePassword());
			list.add(employeeResponse);
		});
		return list;
	}

	@Override
	public EmployeeResponse saveEmployee(EmployeeRequest employeeRequest) {
		Employee emp = setEmployee(employeeRequest);
		emp = employeeRepository.save(emp);
		return setEmployeeResponse(emp);
	}

	private EmployeeResponse setEmployeeResponse(Employee emp) {
		EmployeeResponse employeeResponse = new EmployeeResponse();
		employeeResponse.setEmployeeAge(emp.getEmployeeAge());
		employeeResponse.setEmployeeId(emp.getEmployeeId());
		employeeResponse.setEmployeeMail(emp.getEmployeeMail());
		employeeResponse.setEmployeeName(emp.getEmployeeName());
		employeeResponse.setEmployeePassword(emp.getEmployeePassword());
		return employeeResponse;
	}

	private Employee setEmployee(EmployeeRequest employeeRequest) {
		Employee employee = new Employee();
		employee.setEmployeeAge(employeeRequest.getEmployeeAge());
		employee.setEmployeeId(employeeRequest.getEmployeeId());
		employee.setEmployeeMail(employeeRequest.getEmployeeMail());
		employee.setEmployeeName(employeeRequest.getEmployeeName());
		employee.setEmployeePassword(employeeRequest.getEmployeePassword());
		return employee;
	}

	@Override
	public EmployeeResponse loginEmployee(EmployeeRequest employeeRequest) throws Exception {
		Employee emp = employeeRepository.findByEmailAndPassword(employeeRequest.getEmployeeMail(),
				employeeRequest.getEmployeePassword());
		EmployeeResponse employeeResponse = null;
		if (Objects.nonNull(emp)) {
			employeeResponse = setEmployeeResponse(emp);
		} else {
			throw new Exception("Invalid Credentials");
		}
		return employeeResponse;
	}

	@Override
	public EmployeeResponse editEmployee(EmployeeRequest employeeRequest, String employeeId) {
		Optional<Employee> findById = null;
		if (Objects.nonNull(employeeId)) {
			findById = employeeRepository.findById(employeeId);
		}
		EmployeeResponse employeeResponse = null;
		if (Objects.nonNull(findById) && findById.isPresent()) {
			Employee emp = setEmployee(employeeRequest);
			emp.setEmployeePassword(findById.get().getEmployeePassword());
			emp = employeeRepository.save(emp);
			employeeResponse = setEmployeeResponse(emp);
		}
		return employeeResponse;
	}

	@Override
	public EmployeeResponse getEmployeeById(String employeeId) throws Exception {
		EmployeeResponse employeeResponse = null;
		Optional<Employee> findById = null;
		if (Objects.nonNull(employeeId)) {
			findById = employeeRepository.findById(employeeId);
			if (findById.isPresent()) {
				employeeResponse = setEmployeeResponse(findById.get());
			} else {
				throw new Exception("Employee Id not found");
			}
		}
		return employeeResponse;
	}

	@Override
	public EmployeeResponse forgotPassword(String employeeMail, EmployeeRequest employeeRequest) {
		EmployeeResponse employeeResponse = null;
		if (Objects.nonNull(employeeMail)) {
			Employee employee = employeeRepository.findByEmail(employeeMail);
			if (Objects.nonNull(employee)) {
				employee.setEmployeePassword(employeeRequest.getEmployeePassword());
				Employee emp = employeeRepository.save(employee);
				employeeResponse = setEmployeeResponse(emp);
			}
		}
		return employeeResponse;
	}

	@Override
	public void deleteEmployee(String employeeId) {
		if (Objects.nonNull(employeeId)) {
			employeeRepository.deleteById(employeeId);
		}

	}

	@Override
	public EmployeeResponse adminLoginEmployee(EmployeeRequest employeeRequest) {
		
		return null;
	}

}
