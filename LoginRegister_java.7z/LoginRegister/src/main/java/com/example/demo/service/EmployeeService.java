package com.example.demo.service;

import java.util.List;

import com.example.demo.request.EmployeeRequest;
import com.example.demo.response.EmployeeResponse;

public interface EmployeeService {

	public List<EmployeeResponse> getAllEmployee();
	
	public EmployeeResponse saveEmployee(EmployeeRequest employeeRequest);

	public EmployeeResponse loginEmployee(EmployeeRequest employeeRequest) throws Exception;

	public EmployeeResponse editEmployee(EmployeeRequest employeeRequest, String employeeId);

	public EmployeeResponse getEmployeeById(String employeeId)  throws Exception;

	public EmployeeResponse forgotPassword(String employeeMail, EmployeeRequest employeeRequest);

	public void deleteEmployee(String employeeId);

	public EmployeeResponse adminLoginEmployee(EmployeeRequest employeeRequest);
	
}
