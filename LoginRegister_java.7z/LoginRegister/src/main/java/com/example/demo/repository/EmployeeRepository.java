package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Employee;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, String> {

	@Query("SELECT E FROM Employee AS E")
	public List<Employee> getAllEmployees();

	@Query(value = "SELECT EMP FROM Employee AS EMP WHERE employeeMail=:employeeMail AND employeePassword=:employeePassword")
	public Employee findByEmailAndPassword(@Param("employeeMail") String employeeMail,
			@Param("employeePassword") String employeePassword);

	@Query(value = "SELECT EMP FROM Employee AS EMP WHERE employeeMail=:employeeMail")
	public Employee findByEmail(@Param("employeeMail") String employeeMail);

}
