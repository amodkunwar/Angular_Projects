package com.example.demo.email;

import java.util.Objects;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Employee;
import com.example.demo.model.PasswordReset;
import com.example.demo.repository.EmployeeRepository;

@Service
public class EmailServiceImpl {

	@Autowired
	private JavaMailSender javaMailSender;

	@Autowired
	private EmployeeRepository employeeRepository;

	private String code;

	@Async
	public String sendEmail(String toEmployeeMail) {
		Random random = new Random();
		SimpleMailMessage simpleMailMessage = new SimpleMailMessage();
		simpleMailMessage.setFrom("test@gmail.com");
		simpleMailMessage.setTo(toEmployeeMail);
		simpleMailMessage.setSubject("Password Reset");
		code = String.format("%04d", random.nextInt(10000));
		simpleMailMessage.setText("Please use this code to reset your password : " + code);
		javaMailSender.send(simpleMailMessage);
		return "Email sent successfully !!";
	}

	public void resetPassword(String email, PasswordReset passwordReset) {
		if (passwordReset.getCode().equals(code)) {
			Employee findByEmail = employeeRepository.findByEmail(email);
			if (Objects.nonNull(findByEmail)) {
				Employee employee = new Employee();
				employee.setEmployeeAge(findByEmail.getEmployeeAge());
				employee.setEmployeeId(findByEmail.getEmployeeId());
				employee.setEmployeeMail(findByEmail.getEmployeeMail());
				employee.setEmployeeName(findByEmail.getEmployeeName());
				employee.setEmployeePassword(passwordReset.getPassword());
				employeeRepository.save(employee);
			}
		}
	}

}
