package com.example.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "admin")
public class Admin {

	@Id
	@Column(name = "adminId")
	private String adminId;

	@Column(name = "adminName")
	private String adminName;

	@Column(name = "adminAge")
	private Integer adminAge;

	@Column(name = "adminMail")
	private String adminMail;

	@Column(name = "adminPwd")
	private String adminPwd;

	public String getAdminId() {
		return adminId;
	}

	public void setAdminId(String adminId) {
		this.adminId = adminId;
	}

	public String getAdminName() {
		return adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	public Integer getAdminAge() {
		return adminAge;
	}

	public void setAdminAge(Integer adminAge) {
		this.adminAge = adminAge;
	}

	public String getAdminMail() {
		return adminMail;
	}

	public void setAdminMail(String adminMail) {
		this.adminMail = adminMail;
	}

	public String getAdminPwd() {
		return adminPwd;
	}

	public void setAdminPwd(String adminPwd) {
		this.adminPwd = adminPwd;
	}

}
