package com.example.demo.service;

import com.example.demo.request.AdminRequest;
import com.example.demo.response.AdminResponse;

public interface AdminService {

	public AdminResponse adminLogin(AdminRequest adminRequest);
	
}
