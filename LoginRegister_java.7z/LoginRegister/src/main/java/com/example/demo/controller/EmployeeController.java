package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.email.EmailServiceImpl;
import com.example.demo.model.PasswordReset;
import com.example.demo.request.EmployeeRequest;
import com.example.demo.response.EmployeeResponse;
import com.example.demo.service.EmployeeService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/employee")
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	@Autowired
	private EmailServiceImpl emailServiceImpl;

	@GetMapping("/get")
	public List<EmployeeResponse> getAllEmployee() {
		return employeeService.getAllEmployee();
	}

	@PostMapping("/register")
	public @ResponseBody EmployeeResponse addEmployee(@RequestBody EmployeeRequest employeeRequest) {
		return employeeService.saveEmployee(employeeRequest);
	}

	@PostMapping("/login")
	public @ResponseBody EmployeeResponse loginEmployee(@RequestBody EmployeeRequest employeeRequest) throws Exception {
		return employeeService.loginEmployee(employeeRequest);
	}

	@PutMapping("/edit/{employeeId}")
	public @ResponseBody EmployeeResponse editEmployee(@RequestBody EmployeeRequest employeeRequest,
			@PathVariable("employeeId") String employeeId) {
		return employeeService.editEmployee(employeeRequest, employeeId);
	}

	@GetMapping("/{employeeId}")
	public @ResponseBody EmployeeResponse getEmployeeById(@PathVariable("employeeId") String employeeId)
			throws Exception {
		return employeeService.getEmployeeById(employeeId);
	}

	@PostMapping("/{employeeMail}")
	public String emailSend(@PathVariable("employeeMail") String employeeMail,
			@RequestBody EmployeeRequest employeeRequest) {
		return emailServiceImpl.sendEmail(employeeMail);
	}

	@DeleteMapping("/delete/{employeeId}")
	public void deleteEmployee(@PathVariable("employeeId") String employeeId) {
		employeeService.deleteEmployee(employeeId);
	}

	@PutMapping("/{employeeMail}")
	public String resetPassword(@PathVariable("employeeMail") String employeeMail,
			@RequestBody PasswordReset passwordReset) {
		emailServiceImpl.resetPassword(employeeMail, passwordReset);
		return "Password changed successful!!";
	}

//	@PostMapping("/adminLogin")
//	public @ResponseBody EmployeeResponse adminLoginEmployee(@RequestBody EmployeeRequest employeeRequest) throws Exception {
//		return employeeService.adminLoginEmployee(employeeRequest);
//	}
}
